# Download the zip file and extract it
